#!/bin/bash
# ============================================
# Initialize Let's Encrypt SSL Certificates
# ============================================
# Run this script to obtain SSL certificates for heavenlydrops.access.ly

set -e

# Configuration
DOMAINS=("heavenlydrops.access.ly")
EMAIL="admin@heavenlydrops.com"  # Replace with your email
STAGING=0  # Set to 1 for testing

# Paths
DATA_PATH="./deployment/certbot"
RSA_KEY_SIZE=4096

echo "### Creating dummy certificates for $DOMAINS ..."

# Create directories
mkdir -p "$DATA_PATH/conf/live/$DOMAINS"

# Generate dummy certificate
openssl req -x509 -nodes -newkey rsa:$RSA_KEY_SIZE -days 1 \
    -keyout "$DATA_PATH/conf/live/$DOMAINS/privkey.pem" \
    -out "$DATA_PATH/conf/live/$DOMAINS/fullchain.pem" \
    -subj "/CN=localhost"

echo "### Starting nginx ..."
docker-compose up --force-recreate -d nginx

echo "### Deleting dummy certificate ..."
rm -rf "$DATA_PATH/conf/live/$DOMAINS"

echo "### Requesting Let's Encrypt certificate for $DOMAINS ..."

# Join domains for certbot
domain_args=""
for domain in "${DOMAINS[@]}"; do
  domain_args="$domain_args -d $domain"
done

# Select appropriate email arg
case "$EMAIL" in
  "") email_arg="--register-unsafely-without-email" ;;
  *) email_arg="--email $EMAIL" ;;
esac

# Enable staging mode if needed
if [ $STAGING != "0" ]; then staging_arg="--staging"; fi

# Run certbot
docker-compose run --rm --entrypoint "\
  certbot certonly --webroot -w /var/www/certbot \
    $staging_arg \
    $email_arg \
    $domain_args \
    --rsa-key-size $RSA_KEY_SIZE \
    --agree-tos \
    --force-renewal \
    --non-interactive \
    " certbot

echo "### Reloading nginx ..."
docker-compose exec nginx nginx -s reload

echo "### SSL certificates obtained successfully!"
echo "### Certificates location: $DATA_PATH/conf/live/$DOMAINS/"
